---
title: Privacy Policy
date: "2018-06-28T00:00:00+01:00"
draft: true
share: false
commentable: false
editable: false

# Optional header image (relative to `static/media/` folder).
header:
  caption: ""
  image: ""
---

Add your privacy policy here and set `draft: false` to publish it. Otherwise, delete this file if you don't need it.

---
# Homepage
type: widget_page

# Homepage is headless, other widget pages are not.
headless: true
---
